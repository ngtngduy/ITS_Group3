"""Reproducible OFFLINE evaluation of stored Member-2 E1 intervals.
No SUMO installation required. No original repository files are modified.
Default reproduces member3 CaliforniaAlgorithm (3, .2, 9, P=2).
Matching: correct segment AND lane, first alarm onset in (start, release].
FAR: false-positive pair-lane interval decisions / all valid decisions.
Episode counts reported separately. See README for interpretation.
"""
from pathlib import Path
import argparse, csv, json, math, hashlib
import xml.etree.ElementTree as ET

SCENARIOS = ['K1_sparse_with_incident', 'K2_dense_with_incident', 'K3_dense_without_incident']

def write_csv(path, rows):
    if not rows: return
    with Path(path).open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)

def read_intervals(folder):
    data = {}
    for path in sorted(folder.glob('e1_S*.xml')):
        for e in ET.parse(path).getroot().findall('interval'):
            b, t, occ = float(e.get('begin')), float(e.get('end')), float(e.get('occupancy'))
            if not math.isfinite(occ) or not 0 <= occ <= 100:
                raise ValueError(f'Invalid occupancy: {path} {e.attrib}')
            key = (t, e.get('id'))
            if key in data: raise ValueError(f'Duplicate interval {key}')
            data[key] = {'begin':b, 'end':t, 'occ':occ, 'speed':float(e.get('speed')), 'flow':float(e.get('flow'))}
    if not data: raise ValueError(f'No E1 data: {folder}')
    return data

class RepoAlgorithm:
    def __init__(self, t1=3., t2=.2, t3=9., persistence=2, strict=False):
        self.t1,self.t2,self.t3,self.p,self.strict = t1,t2,t3,persistence,strict
        self.counter = {}
    def evaluate(self, key, up, down):
        matched = up > 0 and up-down > self.t1 and (up-down)/up > self.t2 and down < self.t3
        old = self.counter.get(key, 0)
        n = old+1 if matched else (0 if self.strict else max(0,old-1))
        self.counter[key]=n
        return matched,n,n>=self.p

def evaluate(folder, args):
    data=read_intervals(folder)
    truth=json.loads((folder/'incident_summary.json').read_text(encoding='utf-8-sig'))
    cfg=ET.parse(folder/'member2_highway.add.xml').getroot()
    positions={e.get('id'): float(e.get('pos')) for e in cfg.findall('inductionLoop')}
    has_incident=truth.get('status')=='completed'
    if not has_incident and truth.get('status') != 'not_configured':
        raise ValueError(f'Incomplete incident metadata: {truth}')
    start,release = (truth['actual_start_time'],truth['release_time']) if has_incident else (None,None)
    correct=None
    if has_incident:
        lane=int(truth['lane_id'].rsplit('_',1)[1]); x=truth['actual_position_m']
        for s in range(1,7):
            if positions[f'S{s}_L{lane}'] < x <= positions[f'S{s+1}_L{lane}']:
                correct=(s,lane)
        if correct is None: raise ValueError('Incident is outside monitored segments')
    algo=RepoAlgorithm(args.t1,args.t2,args.t3,args.persistence,args.strict)
    times=[float(t) for t in range(30,int(args.horizon)+1,30)]
    rows=[]; episodes=[]; prev={}; first=None
    for t in times:
        for s in range(1,7):
            for lane in range(3):
                u,d=f'S{s}_L{lane}',f'S{s+1}_L{lane}'; key=(s,lane)
                if (t,u) not in data or (t,d) not in data:
                    raise ValueError(f'Missing data: {folder.name}, {t}, {u}/{d}')
                a,b=data[t,u],data[t,d]
                if a['begin'] != t-30 or b['begin'] != t-30:
                    raise ValueError('Nonstandard or partial interval')
                matched,count,alarm=algo.evaluate(key,a['occ'],b['occ'])
                onset=alarm and not prev.get(key,False)
                positive=bool(has_incident and key==correct and start<t<=release)
                if onset:
                    label='matched' if positive else 'unmatched'
                    episodes.append(dict(scenario=folder.name,time_s=t,upstream=u,downstream=d,lane=lane,label=label))
                    if positive and first is None: first=t
                rows.append(dict(scenario=folder.name,interval_begin_s=t-30,interval_end_s=t,upstream=u,downstream=d,lane=lane,
                    occ_up_pct=a['occ'],occ_down_pct=b['occ'],occ_diff_pp=round(a['occ']-b['occ'],8),
                    occ_relative=(a['occ']-b['occ'])/a['occ'] if a['occ']>0 else '',
                    speed_up_mps=a['speed'],speed_down_mps=b['speed'],flow_up_veh_h=a['flow'],flow_down_veh_h=b['flow'],
                    thresholds_met=int(matched),counter=count,alarm=int(alarm),alarm_onset=int(onset),
                    incident_start_s=start if has_incident else '',incident_release_s=release if has_incident else '',
                    ground_truth_positive=int(positive),false_alarm_decision=int(alarm and not positive),
                    matched_onset=int(onset and positive)))
                prev[key]=alarm
    false=sum(r['false_alarm_decision'] for r in rows)
    summary=dict(scenario=folder.name,observations=len(rows),incidents=int(has_incident),detected=int(first is not None),
        DR_pct=(100.*int(first is not None) if has_incident else None),false_alarm_decisions=false,FAR_pct=100.*false/len(rows),
        alarm_episodes=len(episodes),unmatched_episodes=sum(e['label']=='unmatched' for e in episodes),
        first_detection_s=first,MTTD_s=(first-start if first is not None else None),
        correct_pair=(f'S{correct[0]}_L{correct[1]}–S{correct[0]+1}_L{correct[1]}' if correct else None))
    return rows,episodes,summary

def plots(rows,out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10})
    for scenario in SCENARIOS:
        rr=[r for r in rows if r['scenario']==scenario and r['upstream']=='S3_L0']
        t=np.array([r['interval_end_s'] for r in rr]); u=np.array([r['occ_up_pct'] for r in rr]); d=np.array([r['occ_down_pct'] for r in rr])
        fig,axes=plt.subplots(2,1,figsize=(9,5.5),sharex=True,layout='constrained')
        axes[0].plot(t,u,label='S3_L0 · thượng lưu',color='#175d99');axes[0].plot(t,d,label='S4_L0 · hạ lưu',color='#d27919')
        axes[0].set_ylabel('Occupancy (%)'); axes[0].legend(loc='upper right',fontsize=9)
        axes[1].plot(t,u-d,color='#175d99',label='OCCup − OCCdown')
        axes[1].axhline(3,ls='--',color='#ad3333',label='T1 = 3 điểm %');axes[1].axhline(0,color='gray',lw=.6)
        axes[1].set_ylabel('Chênh lệch (điểm %)');axes[1].set_xlabel('Thời gian kết thúc chu kỳ (s)');axes[1].legend(loc='upper right',fontsize=9)
        if scenario.startswith(('K1','K2')):
            for ax in axes:
                ax.axvspan(900,1200,color='#dedede',alpha=.6);ax.axvline(900,color='#777',lw=.8);ax.axvline(1200,color='#777',lw=.8)
            for r in rr:
                if r['matched_onset']: axes[1].scatter(r['interval_end_s'],r['occ_diff_pp'],color='#ad3333',marker='v',s=65,zorder=5)
        for ax in axes:ax.set_xlim(0,3600);ax.grid(alpha=.15)
        fig.suptitle(scenario.replace('_',' ')+'\nCặp bao quanh vị trí sự cố; vùng xám là 900–1200 s',fontsize=12)
        if scenario.startswith('K3'):fig.suptitle('K3 · Luồng đông không tiêm sự cố · Cặp S3_L0–S4_L0',fontsize=12)
        fig.savefig(out/f'shockwave_{scenario[:2]}.png',dpi=180);plt.close(fig)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('results'))
    p.add_argument('--input-dir',type=Path,help='Override Member-2 scenario folder; e.g. fresh simulation output')
    p.add_argument('--t1',type=float,default=3.);p.add_argument('--t2',type=float,default=.2);p.add_argument('--t3',type=float,default=9.)
    p.add_argument('--persistence',type=int,default=2);p.add_argument('--strict',action='store_true',help='Reset counter on a failure; changes repository semantics')
    p.add_argument('--horizon',type=int,default=3600);p.add_argument('--no-plots',action='store_true')
    a=p.parse_args()
    if a.horizon<=0 or a.horizon%30 or a.persistence<1: p.error('Horizon must be positive and divisible by 30; persistence >=1')
    a.output.mkdir(parents=True,exist_ok=True)
    rows=[];episodes=[];summary=[];hashes={}
    for s in SCENARIOS:
        folder=(a.input_dir or a.repo/'output/member2')/s
        r,e,m=evaluate(folder,a);rows+=r;episodes+=e;summary.append(m)
        for f in sorted(folder.glob('*')):
            if f.name.startswith('e1_') or f.name in ['incident_summary.json','member2_highway.add.xml']:
                hashes[s+'/'+f.name]=hashlib.sha256(f.read_bytes()).hexdigest()
    write_csv(a.output/'simulation_results.csv',rows)
    write_csv(a.output/'summary_metrics.csv',summary)
    if episodes:write_csv(a.output/'alarm_episodes.csv',episodes)
    delays=[m['MTTD_s'] for m in summary if m['MTTD_s'] is not None]
    aggregate={'incidents':sum(m['incidents'] for m in summary),'detected':sum(m['detected'] for m in summary),
        'observations':len(rows),'false_alarm_decisions':sum(m['false_alarm_decisions'] for m in summary),
        'MTTD_s':sum(delays)/len(delays) if delays else None}
    aggregate['DR_pct']=100*aggregate['detected']/aggregate['incidents'] if aggregate['incidents'] else None
    aggregate['FAR_pct']=100*aggregate['false_alarm_decisions']/aggregate['observations']
    report={'method':'offline replay of rounded E1 XML; strict segment and lane matching; simulation performed separately',
        'parameters':{k:v for k,v in vars(a).items() if k not in ['repo','output','input_dir']},'scenarios':summary,'aggregate':aggregate,'source_sha256':hashes}
    (a.output/'evaluation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    if not a.no_plots:plots(rows,a.output)
    print(json.dumps({'scenarios':summary,'aggregate':aggregate},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
