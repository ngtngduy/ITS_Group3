"""Run: python test_metrics.py --repo /path/to/ITS_Group3"""
import argparse, importlib.util, json, tempfile
from pathlib import Path
from types import SimpleNamespace
from metrics_calculator import RepoAlgorithm, evaluate, SCENARIOS

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);a=p.parse_args()
    spec=importlib.util.spec_from_file_location('original',a.repo/'output/member3/california_algo.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    original=mod.CaliforniaAlgorithm(t1=3,t2=.2,t3=9,persistence_limit=2)
    replica=RepoAlgorithm()
    import csv
    rows=list(csv.DictReader(open(Path(__file__).parent/'results/simulation_results.csv',encoding='utf-8-sig')))
    # Every scenario starts with a fresh detector state.
    scenario=None
    for r in rows:
        if r['scenario']!=scenario:
            scenario=r['scenario'];original=mod.CaliforniaAlgorithm(3,.2,9,2);replica=RepoAlgorithm()
        key=(r['upstream'],r['downstream']);up=float(r['occ_up_pct']);down=float(r['occ_down_pct'])
        assert original.evaluate_incident(key,up,down)==replica.evaluate(key,up,down)[2]==bool(int(r['alarm']))
    # Division by zero and strict boundary tests.
    q=RepoAlgorithm(); assert q.evaluate('a',0,0)[2] is False
    assert q.evaluate('a',8,5)[0] is False # strict > T1
    assert q.evaluate('a',20,9)[0] is False # strict < T3
    root=Path(__file__).parent
    args=SimpleNamespace(t1=3,t2=.2,t3=9,persistence=2,strict=False,horizon=3600)
    _,_,m=evaluate(root/'raw_runs'/SCENARIOS[2],args)
    assert m['DR_pct'] is None and m['MTTD_s'] is None and m['false_alarm_decisions']==5
    # Truncated or absent observations must not silently become zeros.
    with tempfile.TemporaryDirectory() as t:
        try:evaluate(Path(t),args)
        except ValueError:pass
        else:raise AssertionError('Missing data accepted')
    # No detection has undefined MTTD, never zero.
    _,_,m=evaluate(root/'raw_runs'/SCENARIOS[0],args)
    assert m['detected']==0 and m['MTTD_s'] is None
    print(f'PASS: {len(rows)} replay decisions match original class; boundaries, missing data and undefined metrics checked.')
if __name__=='__main__':main()
