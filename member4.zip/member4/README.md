# Tiểu Luận thành viên 4 — ITS Group 3

Báo cáo chính: `../Tieu_luan_ITS_Thanh_vien_4.docx` (Chương 5, mục 5.1–5.3).
Nguồn: https://github.com/ngtngduy/ITS_Group3
Commit: 65e5a3d50515598fb569845793be20cc875560e1
Ngày hoàn thành: 17/11/2026.

## Kết quả chính

Chạy mới SUMO 1.28.0, TraCI 1.28.0; seed K1=42, K2=K3=43.
Dùng `sumo_connector.py` gốc, giữ nguyên mạng, nhu cầu, kỹ thuật dừng xe.
Đánh giá offline XML E1 30 giây, cửa sổ 0–3600 s; 18 cặp-làn mỗi chu kỳ.
Đánh giá đúng logic lớp `CaliforniaAlgorithm` của nhóm, tham số khi chạy
T1=3 điểm phần trăm, T2=0.2, T3=9%, P=2; không dùng mặc định T1=8, T2=.39.

| Kịch bản | DR | FAR quyết định | MTTD |
|---|---:|---:|---:|
| K1 thưa có sự cố | 0% | 0% | không xác định |
| K2 đông có sự cố | 100% | 0.879630% | 60 s |
| K3 đông không tiêm sự cố | không áp dụng | 0.231481% | không áp dụng |

FAR ở đây là số **quyết định dương tính không khớp nhãn / tổng quyết định cặp-làn**, không phải FP/(TP+FP).
Một cảnh báo chỉ khớp khi đúng cặp S3_L0–S4_L0 và 900 < t <= 1200 s.
DR đếm sự cố, không đếm dòng CSV. MTTD chỉ tính sự cố được phát hiện.
Cảnh báo tồn tại nhiều chu kỳ chỉ tạo một episode; FAR theo episode có thể tính
riêng bằng unmatched_episodes / observations, không trộn lẫn hai định nghĩa.
K2 có các cảnh báo sau 1200 s và tại cặp/làn khác có thể phản ánh tác động lan truyền
hoặc phục hồi. FAR này là thước đo theo nhãn chặt, không khẳng định mọi dòng đó là
cảnh báo vô lý về vật lý. Không tự gán DR=100% hay MTTD=0 cho K3.

## File bàn giao

- `metrics_calculator.py`: đọc XML, kiểm tra thiếu/trùng dữ liệu, phát lại thuật toán, ghép nhãn, xuất bảng, vẽ hình.
- `run_member4.py`: chạy cả 3 kịch bản bằng module thành viên 2 rồi tự xử lý kết quả.
- `test_metrics.py`: kiểm tra 6.480 quyết định khớp lớp gốc và các trường hợp biên.
- `results/simulation_results.csv`: 6.480 dòng dữ liệu đầy đủ.
- `results/summary_metrics.csv`, `results/evaluation.json`: bảng kết quả và SHA256 nguồn.
- `results/alarm_episodes.csv`: các lần cảnh báo bắt đầu, tách cảnh báo lặp.
- `results/shockwave_K1.png`, `shockwave_K2.png`, `shockwave_K3.png`: biểu đồ OCC và chênh lệch.
- `raw_runs/`: dữ liệu mới chạy, metadata sự cố, cấu hình và XML cảm biến.
- `sensitivity_P3/`: phân tích độ nhạy trên cùng dữ liệu, P=3; chưa phải bộ ngưỡng tối ưu.
- `simulation_console.log`: nhật ký chạy có cảnh báo phanh khẩn cấp và teleport do va chạm.

## Chạy trên máy của bạn

Cài Python 3.10 trở lên; cài SUMO 1.28.0 và thêm thư mục bin vào PATH.
Trong Terminal của VS Code:

```bash
python -m pip install matplotlib traci==1.28.0
git clone https://github.com/ngtngduy/ITS_Group3.git
```

Đặt thư mục `member4` ngang hàng `ITS_Group3` hoặc dùng đường dẫn tương ứng:

```bash
python member4/metrics_calculator.py --repo ITS_Group3 --input-dir member4/raw_runs --output member4/results
python member4/test_metrics.py --repo ITS_Group3
```

Hai lệnh trên dùng dữ liệu đi kèm, không cần khởi động SUMO.
Chạy mô phỏng mới và tính lại tự động (cần SUMO):

```bash
python member4/run_member4.py --repo ITS_Group3 --sumo-binary sumo
```

Nếu `sumo` không có trong PATH, thay bằng đường dẫn đầy đủ, ví dụ
`--sumo-binary "C:\Program Files (x86)\Eclipse\Sumo\bin\sumo.exe"` (điều chỉnh theo nơi cài thực tế).
Lệnh chạy mới ghi đè các kết quả trong `member4/raw_runs` và `member4/results`.
Các `.sumocfg` trong raw_runs là bản ghi lần chạy; không mở trực tiếp sau khi chuyển
máy vì đường dẫn tương đối phụ thuộc vị trí cũ. `run_member4.py` sinh lại cấu hình
đúng cho máy hiện tại qua `sumo_connector.py`.

Phân tích P=3:

```bash
python member4/metrics_calculator.py --repo ITS_Group3 --input-dir member4/raw_runs --output member4/sensitivity_P3 --persistence 3 --no-plots
```

`--strict` là thử nghiệm thay đổi bộ đếm: khi một chu kỳ không đạt thì đặt lại 0.
Không bật tùy chọn đó khi muốn tái lập số liệu báo cáo này.