"""Run all three real SUMO scenarios, then export Member-4 evaluation and figures."""
import argparse,subprocess,sys
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--sumo-binary',default='sumo');a=p.parse_args()
    here=Path(__file__).resolve().parent
    cmd=[sys.executable,str(a.repo.resolve()/'sumo_connector.py'),'--scenario','all','--seed','42','--output-dir',str(here/'raw_runs'),'--sumo-binary',a.sumo_binary]
    result=subprocess.run(cmd,text=True,capture_output=True)
    (here/'simulation_console.log').write_text(result.stdout+'\n'+result.stderr,encoding='utf-8')
    print(result.stdout)
    if result.returncode:print(result.stderr);raise SystemExit(result.returncode)
    subprocess.run([sys.executable,str(here/'metrics_calculator.py'),'--repo',str(a.repo.resolve()),'--input-dir',str(here/'raw_runs'),'--output',str(here/'results')],check=True)
if __name__=='__main__':main()
